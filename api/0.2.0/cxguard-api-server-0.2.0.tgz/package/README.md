CXGuard API Server 0.2.0 — CXGAPI2. Commercial license required. Guide: https://cxguard-site.vercel.app/api-protection
